<footer class="bg-dark text-light text-center py-3 mt-5">
  <div class="container small">© <?php echo date('Y'); ?> DealTrack SA</div>
</footer>